const accordionItemsHeaders = document.querySelectorAll(".accordion-items-header");

accordionItemsHeaders.forEach(accordionIitemsHeader =>{
    accordionIitemsHeader.addEventListener("click" , event => {
        accordionIitemsHeader.classList.toggle("active");
    });
});